import java.io.FileReader;

public class Hashcode
{
    String filename;
    public Hashcode(String filename)
    {
        this.filename = filename;
    }
}